using UnityEngine;

public class EnemyTank : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float rotationSpeed = 2f;
    public float fireRate = 2f;
    public GameObject bulletPrefab;
    public Transform firePoint;

    private Transform player;
    private float nextFireTime = 5f;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void Update()
    {
        Vector3 directionToPlayer = player.position - transform.position;

        Quaternion lookRotation = Quaternion.LookRotation(directionToPlayer);
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, rotationSpeed * Time.deltaTime);


        transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);

        if (Time.time >= nextFireTime)
        {
            FireBullet();
            nextFireTime = Time.time + Random.Range(1f, 3f) / fireRate;
        }
    }

    void FireBullet()
    {
        // Random value of nextFireTime
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);

        Rigidbody bulletRB = bullet.GetComponent<Rigidbody>();
        bulletRB.AddForce(firePoint.forward * 50f, ForceMode.Impulse);

        Destroy(bullet, 20f);
    }
}