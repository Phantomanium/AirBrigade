using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 10f;
    public float rotationSpeed = 3f;
    public float liftForce = 20f;
    private float heightInput;
    private float strafeInput;
    private float forwardInput;
    private float rotationAmount;
    public float gravityForce = 10f;
    float groundDistance = 29f;
    public float tiltAngle = 15f;


    [SerializeField] private float _rotorSpeed = 100f;
    [SerializeField] private Transform _rotorTransform;
    public GameObject airDropPrefab;
    public Transform spawnPosition;
    private Rigidbody rb;
    public GameObject explosionEffect;
    public float explosionRadius = 5f;
    public float explosionForce = 700f;

    public GameManager gameManager;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    private void Update()
    {
        InputHandler();

        if (!IsGrounded())
        {
            ResetRotation();
        }
        if (Input.GetMouseButtonDown(1))
        {
            Instantiate(airDropPrefab, spawnPosition.position, transform.rotation);
        }
    }

    private void FixedUpdate()
    {
        float verticalForce = heightInput * liftForce - gravityForce;
        Vector3 moveDirection = transform.forward * forwardInput + transform.right * strafeInput;
        rb.AddForce(moveDirection * moveSpeed);
        rb.AddForce(Vector3.up * verticalForce);
        rb.angularVelocity = new Vector3(0f, rotationAmount, 0f);
        _rotorTransform.Rotate(Vector3.up, _rotorSpeed * 100 * Time.deltaTime);
    }

    private void InputHandler()
    {
        float ascendInput = Input.GetKey(KeyCode.Space) ? 1f : 0f;
        float descendInput = Input.GetKey(KeyCode.LeftControl) ? -1f : 0f;
        heightInput = ascendInput + descendInput;
        forwardInput = Input.GetAxis("Vertical");
        strafeInput = Input.GetAxis("Horizontal");
        float rotationInput = Input.GetAxis("Rotation");
        rotationAmount = rotationInput * rotationSpeed;
    }
    bool IsGrounded()
    {
        Vector3 raycastOrigin = transform.position + Vector3.up * 0.1f;
        RaycastHit hit;

        if (Physics.Raycast(raycastOrigin, Vector3.down, out hit, groundDistance))
        {
            if (hit.collider.CompareTag("Ground"))
            {
                Debug.Log("On Ground");
                return true;
            }
        }
        return false;
    }
    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Enemy"))
        {
            Explosion();
            gameManager.GameOver();
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            Explosion();
            gameManager.GameOver();
        }
    }
    private void Explosion()
    {
        Instantiate(explosionEffect, transform.position, transform.rotation);
        Collider[] colliders = Physics.OverlapSphere(transform.position, explosionRadius);
        foreach (Collider nearbyObject in colliders)
        {
            Rigidbody rb = nearbyObject.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.AddExplosionForce(explosionForce, transform.position, explosionRadius);
            }
        }

    }

    void ResetRotation()
    {
        rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
    }
}