using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookAtPlayer : MonoBehaviour
{
    private Transform player;
    public float rotationSpeed = 5.0f;
    public float maxVerticalRotation = 15f; // Maximum vertical rotation in degrees


    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }
    private void Update()
    {
        if (player != null)
        {
            Vector3 directionToTarget = player.position - transform.position;
            Quaternion targetRotation = Quaternion.LookRotation(directionToTarget);

            Vector3 targetEulerAngles = targetRotation.eulerAngles;
            targetEulerAngles.x = Mathf.Clamp(targetEulerAngles.x, -maxVerticalRotation, maxVerticalRotation);

            transform.rotation = Quaternion.Euler(targetEulerAngles);

            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(targetEulerAngles), rotationSpeed * Time.deltaTime);
        }

    }
}
