using UnityEngine;

public class CopterMovement : MonoBehaviour
{
    public float moveSpeed = 35f;
    public float rotationSpeed = 2f;

    private Transform player;
    [SerializeField] private float _rotorSpeed = 100f;
    [SerializeField] private Transform _rotorTransform;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void Update()
    {
        Vector3 directionToPlayer = player.position - transform.position;

        Quaternion lookRotation = Quaternion.LookRotation(directionToPlayer);
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, rotationSpeed * Time.deltaTime);


        transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
    }
    private void FixedUpdate()
    {
        _rotorTransform.Rotate(Vector3.up, _rotorSpeed * 100 * Time.deltaTime);
    }
}