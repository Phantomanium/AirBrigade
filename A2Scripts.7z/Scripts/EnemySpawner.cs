using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject tank;
    public GameObject helicopter;
    public int numberOfTanks = 10;
    public int numberOfHelicopter = 10;
    public float spawnRadiusTank = 350f;
    public float spawnRadiusHelicopter = 350f;

    private int spawnedTanks = 0;
    private int spawnedHelicopter = 0;


    private Terrain terrain;

    private void Start()
    {
        terrain = Terrain.activeTerrain;
    }
    private void Update()
    {
        SpawnEnemies();
    }
    public void EnemyDies(GameObject enemy)
    {
        if (enemy.name.Contains("Tank"))
        {
            spawnedTanks--;
        }
        else if (enemy.name.Contains("Helicopter"))
        {
            spawnedHelicopter--;
        }
    }
    private void SpawnEnemies()
    {
        for (; spawnedTanks < numberOfTanks; spawnedTanks++)
        {
            Vector3 randomPosition = transform.position + Random.insideUnitSphere * spawnRadiusTank;
            float terrainHeight = terrain.SampleHeight(randomPosition) + 10f;
            Vector3 enemyPosition = new Vector3(randomPosition.x, terrainHeight, randomPosition.z);
            Instantiate(tank, enemyPosition, Quaternion.identity);
        }
        for (; spawnedHelicopter < numberOfHelicopter; spawnedHelicopter++)
        {
            Vector3 randomPosition = transform.position + Random.insideUnitSphere * spawnRadiusHelicopter;
            float terrainHeight = terrain.SampleHeight(randomPosition) + Random.Range(40f, 60f);
            Vector3 enemyPosition = new Vector3(randomPosition.x, terrainHeight, randomPosition.z);
            Instantiate(helicopter, enemyPosition, Quaternion.identity);
        }
    }
}
