using UnityEngine;
using UnityEngine.UI;

public class CrosshairFollowMouse : MonoBehaviour
{
    public RectTransform crosshairTransform;

    private void Update()
    {
        Vector2 mousePosition = Input.mousePosition;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            crosshairTransform.parent as RectTransform,
            mousePosition,
            null,
            out Vector2 localMousePosition
        );

        crosshairTransform.localPosition = localMousePosition;
    }
}