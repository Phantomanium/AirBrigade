using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AirDrop : MonoBehaviour
{

    public GameObject explosionEffect;
    public float explosionRadius = 5f;
    public float explosionForce = 700f;
    private Rigidbody rb;
    public GameManager gameManager;
    public GameObject enemySpawner;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        enemySpawner = GameObject.FindGameObjectWithTag("Respawn");
        gameManager = FindObjectOfType<GameManager>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            if (gameManager != null)
            {
                gameManager.IncrementScore(10);
            }
            Explosion();
            EnemySpawner spawnerScript = enemySpawner.GetComponent<EnemySpawner>();
            if (spawnerScript != null)
            {
                spawnerScript.EnemyDies(other.gameObject);
            }
            else
            {
                Debug.LogError("EnemySpawner script not found!");
            }
            Destroy(gameObject);
            Destroy(other.gameObject);
        }
    }
    private void Explosion()
    {
        Instantiate(explosionEffect, transform.position, transform.rotation);
        Collider[] colliders = Physics.OverlapSphere(transform.position, explosionRadius);
        foreach (Collider nearbyObject in colliders)
        {
            Rigidbody rb = nearbyObject.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.AddExplosionForce(explosionForce, transform.position, explosionRadius);
            }
        }

    }
}
