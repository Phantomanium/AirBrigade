using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public GameObject gameoverScreen;
    public TextMeshProUGUI scoreText;
    int score = 0;

    private void Start()
    {
        gameoverScreen.SetActive(false);
    }
    private void Update()
    {
        EndScore();
    }
    public int Score
    {
        get { return score; }
    }
    public void EndScore()
    {
        scoreText.text = "Score: " + score;
    }
    public void GameOver()
    {
        gameoverScreen.SetActive(true);
        Time.timeScale = 0;
        Debug.Log("Game Over!");
    }
    public void IncrementScore(int points)
    {
        score += points;
    }
}