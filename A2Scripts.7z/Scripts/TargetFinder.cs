using UnityEngine;
using UnityEngine.UI;

public class TargetFinder : MonoBehaviour
{
    public GameObject missilePrefab;
    public LayerMask targetLayer;
    public Image crosshairImage;
    private Color targetColor = Color.red;
    private Color defaultColor = Color.white;
    public Transform spawnPosition;
    public Camera raycastCamera;

    private void Start()
    {
        crosshairImage.color = defaultColor;
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            FireMissile();
        }
    }

    private void FireMissile()
    {
        Vector3 mousePosition = Input.mousePosition;

        if (raycastCamera == null)
        {
            Debug.LogError("Raycast camera is not assigned!");
            return;
        }
        Ray ray = raycastCamera.ScreenPointToRay(mousePosition);
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit, Mathf.Infinity, targetLayer))
        {
            crosshairImage.color = targetColor;
            Debug.Log("Target found");

            GameObject missile = Instantiate(missilePrefab, spawnPosition.position, Quaternion.identity);
            HomingMissile missileController = missile.GetComponent<HomingMissile>();

            if (missileController != null)
            {
                missileController.SetTarget(hit.transform);
                crosshairImage.color = targetColor;

            }
        }
        else
        {
            Debug.Log("Ray did not hit anything on the target layer.");
            Debug.DrawRay(ray.origin, ray.direction * 1000f, Color.red);
        }

    }
}
