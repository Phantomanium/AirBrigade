using UnityEngine;

public class HomingMissile : MonoBehaviour
{
    public Transform target;
    public float missileSpeed = 10f;
    public float rotationSpeed = 5f;
    public GameObject explosionEffect;
    public float explosionRadius = 5f;
    public float explosionForce = 700f;
    private Rigidbody rb;
    private GameManager gameManager;
    public GameObject enemySpawner;
    private void Start()
    {
        gameManager = FindObjectOfType<GameManager>();
        enemySpawner = GameObject.FindGameObjectWithTag("Respawn");
        rb = GetComponent<Rigidbody>();
    }

    private void Update()
    {
        if (target != null)
        {
            Vector3 targetDirection = (target.position - transform.position).normalized;

            Quaternion rotation = Quaternion.LookRotation(targetDirection);
            transform.rotation = Quaternion.Slerp(transform.rotation, rotation, rotationSpeed * Time.deltaTime);

            rb.velocity = transform.forward * missileSpeed;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            if (gameManager != null)
            {
                gameManager.IncrementScore(10);
            }
            Explosion();
            EnemySpawner spawnerScript = enemySpawner.GetComponent<EnemySpawner>();
            if (spawnerScript != null)
            {
                spawnerScript.EnemyDies(other.gameObject);
            }
            else
            {
                Debug.LogError("EnemySpawner script not found!");
            }
            Destroy(gameObject);
            Destroy(other.gameObject);
        }
    }
    public void SetTarget(Transform newTarget)
    {
        target = newTarget;
    }
    private void Explosion()
    {
        Instantiate(explosionEffect, transform.position, transform.rotation);
        Collider[] colliders = Physics.OverlapSphere(transform.position, explosionRadius);
        foreach (Collider nearbyObject in colliders)
        {
            Rigidbody rb = nearbyObject.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.AddExplosionForce(explosionForce, transform.position, explosionRadius);
            }
        }

    }
}
